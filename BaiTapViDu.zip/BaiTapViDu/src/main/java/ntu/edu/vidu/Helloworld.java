package ntu.edu.vidu;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Helloworld
 */
@WebServlet("/Helloworld")
public class Helloworld extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Helloworld() {
        //khoi tao neu co
    }
    //Bài tập 1.1
	protected void doGet(HttpServletRequest request, 
						HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		//Bien request luu cac thong tin yeu cau
		//Bien response dai dien ket qua tra ve cua nguoi dung
		
		//De ghi tra du lieu, ta dung writer cua doi tuong request
		PrintWriter dau_ghi_kq = response.getWriter();
		dau_ghi_kq.println("Xin chao hello Servlet");
		
		//Lay du lieu tu tham so URL ?ten=Nhat
		String valueNhanDuoc = request.getParameter("ten");
		dau_ghi_kq.println("<h2>Xin chao</h2>");
		dau_ghi_kq.println(valueNhanDuoc);
	}
	//Bài tập 1.2
	protected void doPost(HttpServletRequest request, 
						HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
	    response.setContentType("text/html; charset=UTF-8");
	    
		String ten = request.getParameter("Ten");
		String tuoi = request.getParameter("tuoi");
		
		//Gui phan hoi ve trinh duyet
		PrintWriter dau_ra_kq = response.getWriter();
		dau_ra_kq.println("<html><title>Kết quả</title></html>");
		dau_ra_kq.println("<h1>Thông tin nhận được</h1>");
		
		 if (ten != null && tuoi != null && !ten.trim().isEmpty() && !tuoi.trim().isEmpty()) {
	            dau_ra_kq.println("<p>Tên của bạn: <strong>" + ten + "</strong></p>");
	            dau_ra_kq.println("<p>Tuổi của bạn: <strong>" + tuoi + "</strong></p>");
	        } else {
	            dau_ra_kq.println("<p style='color: red;'>Vui lòng nhập đầy đủ thông tin!</p>");
	        }
	        dau_ra_kq.println("</body></html>");
	}

}
